<?php
#error code !!
session_start();
error_reporting(0);
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
if($data===false){
    die("connection error");
}
if(isset($_POST['Submit'])){
   $file=$_FILES['file'];
   $filename=$_FILES['file']['name'];
   $filetemp=$_FILES['file']['tmp_name'];
   $filesize=$_FILES['file']['size'];
   $fileerr=$_FILES['file']['error'];
   $filetype=$_FILES['file']['type'];
   $fileext = explode('.',$filename);
   $fileactual =Strtolower(end($fileext));

   $alow=array('jpg','png','jpeg','pdf','webp');
   if(in_array($fileactual,$alow)){
    if($fileerr===0){
    if($filesize<1000000000000){
        $new=(microtime(true)*10000).".".$fileactual;
        $dess='machinary/'.$new;
        try {
           
            if(!move_uploaded_file($filetemp,$dess)){
                return;
            }
            
  //code...
        } catch (\Throwable $th) {
            print_r($th);
          echo $th->getMessage();
          exit;
        }
          }else{
        echo "File too large";
    }
   }}
   $name=$_POST['name'];
   $qty=$_POST['qty'];
   $cty=$_POST['cty'];
   $const=$_POST['const'];
   $ward=$_POST['ward'];
   $desc=$_POST['desc'];
   $file=$_FILES['file'];
   $sql="INSERT INTO Machinaryy(Name,Quality,County,Constituency,Ward,Description,Image_directory) VALUES(
    '$name','$qty','$cty','$const','$ward','$desc','$dess')";
    echo $sql;
   $result = mysqli_query($data,$sql);
    if($result){
        header("location:machinary.php");
    }
    else {
       header("location:machinary.php");
    }
}
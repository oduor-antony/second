<?php
  error_reporting(0);
  session_start();
  if(!isset($_SESSION['username'])){
    header("location:login.php");
  }
  elseif ($_SESSION['usertype']=="Admin") {
    header("location:login.php");
  }
  $host="localhost";
  $user="root";
  $password='';
  $db="whealth";
  $data=mysqli_connect($host,$user,$password,$db);
  if($data===false){
   die("connection error");
}
$file_id=$_GET['id'];
$sql="SELECT * from Fooood where id=' $file_id'";
$resultt=mysqli_query($data, $sql);
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="tttt.css">
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<header>
    <div class="navvv" style="margin: left 0;">
    <div class="icons" style="font-size:large;">
        Sustainable Food Services
    </div>
    <ul style="margin: left 0;">
            <li><a href="food.php">Food</a></li>
            <li><a href="machinary.php">Machinary</a></li>
            <li><a href="land.php">Land</a></li>
            <li><a href="common_stock.php">Store</a></li>
        </ul>
    </div>
</header>
<section class="prod-sect">
 <div class="sevices-one">
  <center>
  <h2 class="text-primary" style="paddind:20px;background-color:white;margin-top:4px;">Product Details</h2>
</center>
  <?php
    while($info=mysqli_fetch_array($resultt)){
      $image=$info['Image_directory'];
      $contyy=$info['County'];
      $word=$info['Ward'];
      $const=$info['Constituency'];
      $Desk=$info['Description'];
      ?>
      <table>
        <tr></tr>
        <?php
    echo '
    <section style="display:flex">
      <div class="img-div">
        <img style="width:500px; height:100%; border-radius:5%;"  src="'.$image.'" alt="food-image">
     </div>  
     <h4 class="location">Location:</h4>
  <section class="details-iteme">
      <div class="arrangement">
       <h5 class="ggg">County:</h5>
      <h5>'.$contyy.'</h5>
       </div>
       <div class="arrangement" >
       <h5 class="ggg">Constituency:</h5>
      <h5>'.$const.'</h5>
       </div>
       <div class="arrangement">
       <h5 class="ggg">Ward:</h5>
      <h5>'.$word.'</h5>
       </div>  
    </div>
    </div>';
     }?>
</section>
</table>
<?php
 include 'footer.php';
?>
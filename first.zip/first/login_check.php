<?php
$host="localhost";
$db="whealth";
$pass="";
$user="root";
$data=mysqli_connect($host,$user,$pass,$db);
if($data===false){
  die('error');
}
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name=$_POST['username'];
    $pass=$_POST['password'];
    $sql="select * from users where username='".$name."' AND password='".$pass."'";
    $result=mysqli_query($data,$sql);
    $row=mysqli_fetch_array($result);
    if($row["usertype"]=="user"){
        $_SESSION['username']=$name;
        $_SESSION['usertype']="user";
        header("location:food.php");
    }
    else if($row["usertype"]=="admin"){
        $_SESSION['username']=$name;
        $_SESSION['usertype']="Admin";
        echo $_SESSION['username'];
        header("location:adminHome.php");
    }
    else{
        $_message="username or password do not match";
        $_SESSION['loginMessage']=$_message;
        header("location:login.php");
    }
}
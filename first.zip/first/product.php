
<body>
<?php
session_start();
  if(!isset($_SESSION['username'])){
    header("location:login.php");
  }
  elseif ($_SESSION['usertype']=="Admin") {
    header("location:login.php");
  }
?>
<link rel="stylesheet" type="text/css" href="studentHome.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<body class="students-body">
     <nav class="Main-nav2">
		<label class="logo-1">Equity</label>
		<ul class="nav-links">
			<li><a href="index.php">Home</a></li>
			<li><a href="">Contact</a></li>
			<li><a href="about_us.php">About Us</a></li>
		</ul>
	  </nav>
	 <div>
	<div class="main-section">
	<?php
	   include 'sidebar.php';
	?>
	</div>
	<div class="mainLink-one">
       <div class="first-item">
        <h3>first item</h3>
       </Div>
      <div class="second-item">
        <h3>second item</h3>
      </Div>
      <div class="third-item">
        <h3>third item</h3>
      </Div>
    </div>
	 </div>
</body>
</html>

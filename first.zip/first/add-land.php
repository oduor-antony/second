<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="add-food.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
   include 'nav2.php';
?>
 <section class="form-container">
 <form action="add_land_check.php" method="POST" enctype="multipart/form-data" onsubmit="return valid()">
        <h2 class="spacial-case" >Add Land</h2>
        <h3>Land Details</h3>
        <input type="text" placeholder="Owners Name" class="food-inputs" name="Name" required>
        <input type="text" placeholder="Size" class="food-inputs" name="Size" required>
        <h3>Location Details</h3>
        <input type="text" placeholder="County" class="food-inputs" name="County" required>
        <input type="text" placeholder="Constituency" class="food-inputs" name="Constituency" required>
        <input type="text" placeholder="Ward" class="food-inputs" name="Ward" required>
        <h3> Land Image</h3>
        <input type="file"  name="file" class="food-inputs" required>
        <h3>Description</h3>
        <textarea name="Description" id="food-desc" placeholder="Land Description" class="food-inputs" type="text" required></textarea>
        <br>
        <br>
        <input type="submit" value="Submit" Name="Submit" class="spacial-case1" required>
    </form>
 </section>
 <style>
  .personal{
    margin-left:50px;
    width: 20px;
    height:20px;
    
  }
.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 400,
  'GRAD' 0,
  'opsz' 48
}
</style>
<?php
  include 'Links.php';
  error_reporting(0);
?>
<center>
     <div class="form_deg">
        <center class="title_deg">
            Registration form
            <h4>
                <?php 
                error_reporting(0);
                session_start();
                session_destroy();
              echo $_SESSION['registerMessage'];
                ?>
            </h4>
                <form action="regist_check.php" method="POST" class="login_form" enctype="multipart/form-data">
                <div>
                    <label class="label_deg">Username</label>
                    <input type="text" name="username">
                </div>
                <div>
                <label class="label_deg">Address</label>
                <input type="text" name="address">
            </div>
            <div>
                <label class="label_deg">Phone</label>
                <input type="numbers" name="phone">
            </div>
            <div>
                <label class="label_deg">Email</label>
                <input type="text" name="email">
            </div>
            <div>
                <label class="label_deg">Usertype</label>
                <input type="text" name="usertype">
           </div>
            <div>
                    <label class="label_deg">Password</label>
                    <input type="Password" name="password">
                </div>
                    
                    <input class="btn btn-primary" type="submit" name="Register" value="Register">
                </div>
    
            </form>
            </h4>
        </center>
    </div>
</center>
</body>
</html>
<?php
   #error code !!
   session_start();
   /*database connectio*/
   $host="localhost";
   $user="root";
   $password="";
   $db="whealth";
   $data=mysqli_connect($host,$user,$password,$db);
   if($data===false){
       die("connection error");
   }
   if(isset($_POST['Upload'])){
    $data_name=$_POST['name'];
    $data_email=$_POST['email'];
    $data_phone=$_POST['phone'];
    $data_message=$_POST['message'];
    $sql="INSERT INTO recomandations(name,email,phone,message) VALUES('$data_name','$data_email','$data_phone','$data_message')";
    $result=mysqli_query($data,$sql);
    if($result=="false"){
        $_SESSION['recomandation']='Upload error';
    }else{
        header("location:index.php");
    }
}
?>
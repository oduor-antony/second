<?php
#error code !!
session_start();
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
if($data===false){
    die("connection error");
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>user details</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body style="width:300px;height:300px;">
 <center>
   <h4>User Name</h4>
   <a href="#">change User Details</a>
   <br>
   <br>
   <br>
   <a href="index.php"><span class="material-symbols-outlined">
    logout
    </a>
</center>
<style>
    body{
        background-color:#333;
        width:fit-content;
        height:fit-content;
        margin-left:1000px;
        transform:translate(10%,10%);
        border:1px solid black;
        z-index: 10;
    }
    .material-symbols-outlined {
      font-variation-settings:
      'FILL' 0,
      'wght' 400,
      'GRAD' 0,
      'opsz' 48
    }
    </style>
    <script src="web-js.js"></Script>
</body>
</html>
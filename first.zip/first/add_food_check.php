<?php
#error code !!
session_start();
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
if($data===false){
    die("connection error");
}
if(isset($_POST['Submit'])){
   $file=$_FILES['file'];
   $filename=$_FILES['file']['name'];
   $filetemp=$_FILES['file']['tmp_name'];
   $filesize=$_FILES['file']['size'];
   $fileerr=$_FILES['file']['error'];
   $filetype=$_FILES['file']['type'];
   $fileext = explode('.',$filename);
   $fileactual =Strtolower(end($fileext));
   $alow=array('jpg','png','jpeg','pdf','webp');
   if(in_array($fileactual,$alow)){
    if($fileerr===0){
    if($filesize<1000000000000){
        $new=uniqid('',true).".".$fileactual;
        $dest='food/'.$new;
        move_uploaded_file($filetemp,$dest);
    }
   }}
   $name=$_POST['name'];
   $qty=$_POST['qty'];
   $cty=$_POST['cty'];
   $const=$_POST['const'];
   $ward=$_POST['ward'];
   $desc=$_POST['desc'];
   $sql="INSERT INTO Fooood(name,quantity,County,Constituency,Ward,Image_directory,Description) VALUES(
    '$name','$qty','$cty','$const','$ward','$dest','$desc')";
   $result = mysqli_query($data,$sql);
    if($result){
        header("location:food.php");
    }
    else {
       echo('error');
    }
}
<div class="navvv">
<div class="icons">
        DONATE SURPLUS
    </div>
    <ul style="margin: left 0;">
            <li><a href="food.php">Food</a></li>
            <li><a href="machinary.php">Machinary</a></li>
            <li><a href="land.php">Land</a></li>
            <li><a href="common_stock.php">Store</a></li>
        <a href="details-change.php" class="personal" style="color:blue" onclick="up()"><span class="material-symbols-outlined" style="amargin-right:10px">
             person_filled
            </span></a>
        </ul>
  </div>
<?php
$host="localhost";
$db="whealth";
$pass="";
$user="root";
$data=mysqli_connect($host,$user,$pass,$db);
if($data===false){
  die('error');
}
$sql="SELECT * from storage";
$result=mysqli_query($data,$sql);
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" type="text/css" href="tttt.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
   include 'nav2.php';
?>
<header class="free-food" style="height:300px padding: 10px;">
<img src="images/icons-hub.png" alt="" style="width:200px;height: 100%;margin-left:0x;border-radius:5px;">
<form action="" class="form-search">
            <label for="" Style="margin-left:250px;margin-bottom:10px;flex:2">Search</label>
            <input type="text" style="width:200px;height:30px;margin: 5px;border-radius:10px;margin-left:250px;margin-bottom:100px;flex:2"placeholder="search prouct">
        </form>
      <button class="img-list" style="top:100px;cursor:pointer;flex:1;align-item:center;margin-top:100px;margin-right:100px justify-content:center"><a href="update-store.php" class="material-symbols-outlined">
add
</a>
    </button>
</header>
 <style>
  .personal{
    margin-left:50px;
    width: 20px;
    height:20px;
    
  }
.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 400,
  'GRAD' 0,
  'opsz' 48
}
</style>
<section class="stock-part">
  <center>
    <h2>Common Store</h2>
  </center>
  <div class="outside-container">
   <?php
      while($info=mysqli_fetch_array($result)){
        $image=$info['Image_directory'];
        $name=$info['Name'];
        $Description=$info['Description'];
        echo '
        <div class="inside-container" style="justify-content:center;">
        <div>
        <a href="request2.php?id='.$info['Id'].'"" style="link-style-type:none;">
        <img src="'.$image.'" class="image-item1" value="" style="width:100%;padding:5px 0;" atl="food-image"></div>
        <div style="color:blue;">
        '.$name.'
        </div>
        </div>
        ';?>
        </a> 
       <?php 
      }
    ?>
    </div>
  
</section>
<?php
   include 'footer.php';
 ?>



 
<?php
#error code !!
session_start();
// error_reporting(0);
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
if($data===false){
    die("connection error");
}
if(isset($_POST['Submit'])){
    $file=$_FILES['file'];
    $filename=$_FILES['file']['name'];
    $filetemp=$_FILES['file']['tmp_name'];
    $filesize=$_FILES['file']['size'];
    $fileerr=$_FILES['file']['error'];
    $filetype=$_FILES['file']['type'];
    $fileext = explode('.',$filename);
    $fileactual =Strtolower(end($fileext));
    $alow=array('jpg','png','jpeg','pdf','webp');
    if(in_array($fileactual,$alow)){
     if($fileerr===0){
     if($filesize<1000000000000){
         $new=uniqid('',true).".".$fileactual;
         $dess='land/'.$new;
         move_uploaded_file($filetemp,$dess);
     }
    }}
   $name=$_POST['Name'];
   $Size=$_POST['Size'];
   $County=$_POST['County'];
   $Constituency=$_POST['Constituency'];
   $Ward=$_POST['Ward'];
   $Description=$_POST['Description'];
   $sql="INSERT INTO Land(Owner_name,Size,County,Constituency,Ward,Description,Image_directory) VALUES(
    '$name','$Size','$County','$Constituency','$Ward','$Description','$dess')";
    echo $sql;
   $result = mysqli_query($data,$sql);
    if($result==="false"){
       echo('error');
    }
    else {
       header("location:land.php");
    }
}
<?php
   session_start();
   if(!isset($_SESSION['username'])){
     header("location:login.php");
   }
   elseif ($_SESSION['usertype']=="user") {
     header("location:login.php");
   }
   ?>
   <!DOCTYPE html>
   <html>
   <head>
       <link rel="stylesheet" type="text/css" href="tttt.css">
       <link rel="stylesheet" type="text/css" href="admin2.css">
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
   <header>
       <div class="icons">
       ADMINISTRATION PANNEL
       </div>
       <div class="nav">
       <ul>
               <li><a href="food.php">Food</a></li>
               <li><a href="machinary.php">Machinary</a></li>
               <li><a href="land.php">Land</a></li>
               <li><a href="common_stock.php">Store</a></li>
           </ul>
       </div>
       <div class="side-bar">
       </div>
   </header>
    <h3 class="sevices">Transprency Is Our Core Ambition</h3>
    <div class="sidee-bar">
        <p class="sidebar-headline"> ADMINISTRATION</p>
        <ul>
          <li><a href="#" class="service-item">Food Services</a></li>
          <li><a href="#" class="service-item">Machinary Services</a></li>
          <li><a href="#"class="service-item">Land Services</a></li>
          <li><a href="#"class="service-item">Store Services</a></li>
          <li><a href="recomandation.php" class="service-item">Recommandations</a></li>
        </ul>
        </div>
        
 
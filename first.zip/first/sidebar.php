<aside class="sidebar">
		<ul class="sidebar-links">
			<li>
				<a href="product.php" class="sidebar-link">View products</a>
			</li>
			<li>
				<a href="" class="sidebar-link">Make request</a>
			</li>
			<li>
				<a href="" class="sidebar-link">Add products</a>
			</li>
			<li>
				<a href="" class="sidebar-link">Pending request</a>
			</li>
			<li>
				<a href="" class="sidebar-link">recommandation</a>
			</li>
		</ul>
	</aside>
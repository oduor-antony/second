<?php
   session_start();   
   if(!isset($_SESSION['username'])){
     header("location:login.php");
   }
   elseif ($_SESSION['usertype']=="user") {
     header("location:login.php");
   }
   $host="localhost";
   $user="root";
   $password='';
   $db="whealth";
   $data=mysqli_connect($host,$user,$password,$db);
   if($data===false){
    die("connection error");
}
   $sql="SELECT * from recomandations";
   $result=mysqli_query($data,$sql);
   ?>
   <!DOCTYPE html>
   <html>
   <head>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
you're welcome
       <link rel="stylesheet" type="text/css" href="tttt.css">
       <link rel="stylesheet" type="text/css" href="admin2.css">
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
   <header>
       <div class="icons">
       ADMINISTRATION PANNEL
       </div>
       <div class="nav">
       <ul>
               <li><a href="studentHome.php">Home</a></li>
               <li><a href="food.php">Food</a></li>
               <li><a href="machinary.php">Machinary</a></li>
               <li><a href="land.php">Land</a></li>
               <li><a href="common_stock.php">Store</a></li>
           </ul>
       </div>
       <div class="side-bar">
       </div>
   </header>
    <h3 class="sevices">Transprency Is Our Core Ambition</h3>
    <div class="main-information">
    <div class="sidee-bar">
        <p class="sidebar-headline"> ADMINISTRATION</p>
        <ul>
          <li><a href="update_food.php" class="service-item">Food Services</a></li>
          <li><a href="#" class="service-item">Machinary Services</a></li>
          <li><a href="#"class="service-item">Land Services</a></li>
          <li><a href="#"class="service-item">Store Services</a></li>
          <li><a href="recomandation.php" class="service-item">Recommandations</a></li>
        </ul>
    </div>
    <div class="information">
        <table class="reco-table">
          <tr class="table-row">
          <th class="table-list">No. </th>
            <th class="table-list">Name</th>
            <th class="table-list">Email</th>
            <th class="table-list">Phone</th>
            <th class="table-list">Massege</th>
          </tr>
          <?php
             while($info=$result->fetch_assoc()){
          ?>
          <tr>
            <th class="table-list"><?php
                 echo "{$info['id']}";
            ?></th>
            <th class="table-list"><?php
                 echo "{$info['name']}";
            ?></th>
            <th class="table-list"><?php
                 echo "{$info['email']}";
            ?></th>
            <th class="table-list"><?php
                 echo "{$info['phone']}";
            ?></th>
            <th class="table-list"><?php
                 echo "{$info['message']}";
            ?></th>
          </tr>
          <?php
            }
          ?>
        </table>
    </div>
    <div>
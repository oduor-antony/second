<?php
#error code !!
error_reporting(0);
session_start();
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
if($data===false){
    die("connection error");
}
if(isset($_POST['Register']))
{
    $data_username=$_POST['username'];
    $data_address=$_POST['address'];
    $data_phone=$_POST['phone'];
    $data_email=$_POST['email'];
    $data_usertype=$_POST['usertype'];
    $data_password=$_POST['password'];

  $sql="INSERT INTO users(username,address,phone,email,usertype,password) VALUES('$data_username','$data_address','$data_phone','$data_email','$data_usertype','$data_password')";

  $result=mysqli_query($data, $sql);

if($result){
    header("location:login.php");
}
else{
    $_message='please fill all the fields';
    $_SESSION['registerMessage']=$_message;
    header("location:register.php");

    
}
}
?>
<nav> 
		 <label class="logo">SUSTAINABLE FOODS </label>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="">Contact</a></li>
			<li><a href="about_us.php">About Us</a></li>
			<li><a href="login.php" class="btn btn-success">Login</a></li>
            <li><a href="register.php" class="btn btn-success">Register</a></li>
		</ul>
	</nav> 
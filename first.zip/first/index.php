<?php
   include 'Links.php';
   include 'navbar.php';
   session_start();
   error_reporting(0);

?>
<body>
	<div class="section1">
		<label class="img_text">SUSTAINABLE FOOD SYSTEMS</label>
		<img class="main_img" src="images/icons-hub.png">
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
      	<img class="welcome_img" src="images/more.jpeg">	
			</div>
			<div class="col-md-8">
				<h1>Welcome To Equity Enhancement Programs</h1>
				<p>
					This Platform is ment to address the issue of wastage across the country, it will ensure that food materials which may go to waste is well utilized and channelled to the right places unlike leaving it to go at waste, this will ensure that the no-haves also manage to put food on the table just like the haves. The well wishers will be required to give not only food staff but other staffs too. The motive of this program is to ensure that if not all the people then most of the people manage to put food on the table and drive their dreams to the best level of their expectation.
				</p>
			</div>
		</div>
	</div>
	<center>
		<h1>Our Directors</h1>
	</center>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img class="teacher" src="images/ratemo.png">
				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
			</div>
			<div class="col-md-4">
				<img class="teacher" src="images/wengine.jpeg">
				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
			</div>
			<div class="col-md-4">
				<img class="teacher" src="images/person3.jpg">
				<p>in a vibrant, academically challenging, and encouraging environment where manifold viewpoints are prized and celebrated.</p>
			</div>
		</div>
	</div>
	<center>
		<h1>Areas Of Concern </h1>
	</center>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img class="teacher" src="images/web.jpg">
				<h3>Food Sharing</h3>
			</div>
			<div class="col-md-4">
				<img class="teacher" src="images/graphic.png">
				<h3>Tools Sharing</h3>
			</div>
			<div class="col-md-4">
				<img class="teacher" src="images/marketing.jpg">
				<h3>Common store</h3>
			</div>
		</div>
	</div>

	<center>
		<?php

		echo $_SESSION['recomandation'];
		?>
		<h1 class="adm">Recommandation</h1>
	</center>
	<div align="center" class="admission_form">
        <form action="recomandation_check.php" method="POST">
		<div class="adm_int">
			<label class="label_text">Name</label>
			<input class="input_deg" type="text" name="name">
 </div>
		<div class="adm_int">
			<label class="label_text">Email</label>
			<input class="input_deg" type="text" name="email">
		</div>
		<div class="adm_int">
			<label class="label_text">Phone</label>
			<input class="input_deg" type="text" name="phone">
		</div>
		<div class="adm_int">
			<label class="label_text">Message</label>
			<textarea class="input_txt" name="message"></textarea>
		</div>
		<div class="adm_int" >
			<input class="btn btn-primary" id="submit" type="submit" value="Upload" name="Upload">
		</div>
		</form>
	</div>
	<?php
   include 'footer.php';
 ?>
</body>
</html>
<?php
#error code !!
session_start();
/*database connectio*/
$host="localhost";
$user="root";
$password="";
$db="whealth";
$data=mysqli_connect($host,$user,$password,$db);
   if($data===false){
    die("error");
   }
   echo $db;
   if(isset($_POST['Submit'])){
      $file=$_FILES['file'];
      $filename=$_FILES['file']['name'];
      $filetemp=$_FILES['file']['tmp_name'];
      $filesize=$_FILES['file']['size'];
      $fileerr=$_FILES['file']['error'];
      $filetype=$_FILES['file']['type'];
      $fileext = explode('.',$filename);
      $fileactual =Strtolower(end($fileext));
      $alow=array('jpg','png','jpeg','pdf','webp');
      if(in_array($fileactual,$alow)){
       if($fileerr===0){
       if($filesize<1000000000000){
           $new=uniqid('',true).".".$fileactual;
           $deee='storage/'.$new;
           move_uploaded_file($filetemp,$deee);
       }
      }}
   $name=$_POST['name'];
   $quantity=$_POST['quantity'];
   $county=$_POST['county'];
   $contituency=$_POST['constituency'];
   $ward=$_POST['ward'];
   $description=$_POST['Description'];
$sql="INSERT INTO storage(Name,Quantity,County,Constituency,Ward,Description,Image_directory) VALUES('$name','$quantity','$county','$contituency','$ward','$description','$deee')";
echo '$sql';
$result=mysqli_query($data,$sql);
echo $result;
if(!$result){
   echo('error');
}
else{
   header('location:common_stock.php');
}
}